#include <stdio.h>
#include <string.h>

void print_characters(a *str) {
    int i;
    int len = strlen(str);
    for (i = 0; i < len; i++) {
        printf("%c\n", str[i]);
    }
}

int main(int argc, a *argv[]) {
    if (argc < 2) {
        printf(stderr, "Error: Stroka ne ykazana\n");
        return 1;
    }

    print_characters(argv[1]);

    return 0;
}
